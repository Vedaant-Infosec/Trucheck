import sys
from PyQt5 import QtWidgets, QtCore
from PyQt5.QtWidgets import QMessageBox, QApplication, QWidget, QPushButton, QVBoxLayout, QLabel, QListWidget, QHBoxLayout
from PyQt5.QtCore import Qt, QTimer

from image_to_text import * 

class CollapsibleBox(QtWidgets.QWidget):
    def __init__(self, title="", parent=None):
        super(CollapsibleBox, self).__init__(parent)

        light_sky_blue = "#a3d8f4"  # Lighter version of sky blue for the titles

        self.toggle_button = QtWidgets.QToolButton(
            text=title, checkable=True, checked=False
        )
        self.toggle_button.setStyleSheet(f"QToolButton {{ border: none; background-color: {light_sky_blue}; font-size: 22px; color: white; text-align: center; font-family: 'Lucida Sans'; padding: 8px}}")
        self.toggle_button.setToolButtonStyle(QtCore.Qt.ToolButtonTextBesideIcon)
        self.toggle_button.setArrowType(QtCore.Qt.RightArrow)
        self.toggle_button.pressed.connect(self.on_pressed)

        button_layout = QtWidgets.QHBoxLayout()
        button_layout.addStretch()  # Stretchable space on the left
        button_layout.addWidget(self.toggle_button)
        button_layout.addStretch()  # Stretchable space on the right

        self.content_area = QtWidgets.QScrollArea(maximumHeight=0, minimumHeight=0)
        self.content_area.setSizePolicy(QtWidgets.QSizePolicy.Expanding, QtWidgets.QSizePolicy.Fixed)
        self.content_area.setFrameShape(QtWidgets.QFrame.NoFrame)

        lay = QtWidgets.QVBoxLayout(self)
        lay.setSpacing(0)
        lay.setContentsMargins(0, 0, 0, 0)
        lay.addLayout(button_layout)
        lay.addWidget(self.content_area)

        self.list_widget = QListWidget()
        self.content_area.setWidget(self.list_widget)
        self.list_widget.setStyleSheet("background-color: white; font-size: 18px; color: black; font-family: 'Lucida Sans'")

    @QtCore.pyqtSlot()
    def on_pressed(self):
        checked = self.toggle_button.isChecked()
        self.toggle_button.setArrowType(QtCore.Qt.DownArrow if not checked else QtCore.Qt.RightArrow)
        self.content_area.setMaximumHeight(self.list_widget.sizeHint().height() if not checked else 0)
        self.toggle_button.setChecked(not checked)

    def setContent(self, items):
        self.list_widget.clear()
        if items:
            self.list_widget.addItems(items)
        else:
            self.list_widget.addItem("Nothing yet, go on, verify something!")
        self.content_area.setMaximumHeight(self.list_widget.sizeHint().height())
        self.adjustSize()

class VerifyApp(QWidget):
    def __init__(self):
        super().__init__()

        self.setWindowTitle("TruCheck Text Verifier")
        self.setFixedSize(600, 600)
        self.setStyleSheet("background-color: #f0f8ff;")  

        self.heading_label = QLabel("TruCheck", self)
        self.heading_label.setAlignment(Qt.AlignCenter)
        self.heading_label.setStyleSheet("font-size: 29px; font-weight: bold; color: #d14c4a; font-family: 'Lucida Sans';")

        layout = QVBoxLayout()
        layout.addWidget(self.heading_label)
        self.verify_button = QPushButton("Verify", self)
        self.verify_button.setStyleSheet("background-color: #d14c4a; color: white; font-size: 20px; padding: 10px; border: none; border-radius: 5px; font-family: 'Lucida Sans';")
        self.verify_button.clicked.connect(self.run_verification)
        layout.addWidget(self.verify_button)

        self.capture_label = QLabel(self)
        self.capture_label.setAlignment(Qt.AlignCenter)
        self.capture_label.setStyleSheet("font-size: 20px; color: #d14c4a; font-family: 'Lucida Sans';")
        layout.addWidget(self.capture_label)

        h_layout = QHBoxLayout()

        self.true_news_box = CollapsibleBox("True News")
        self.fake_news_box = CollapsibleBox("Fake News")

        self.true_news_box.setContent([])
        self.fake_news_box.setContent([])

        h_layout.addWidget(self.true_news_box)
        h_layout.addWidget(self.fake_news_box)

        layout.addLayout(h_layout)
        self.setLayout(layout)

        self.countdown_value = 3
        self.timer = QTimer()
        self.timer.timeout.connect(self.update_countdown)

    def run_verification(self):
        """Begin the countdown before capturing the screen."""
        self.countdown_value = 3  
        self.capture_label.setText(f"Capturing in {self.countdown_value}...")
        self.timer.start(1000)

    def update_countdown(self):
        """Updates the countdown each second."""
        self.countdown_value -= 1
        if self.countdown_value > 0:
            self.capture_label.setText(f"Capturing in {self.countdown_value}...")
        else:
            self.timer.stop()
            self.capture_screen()

    def capture_screen(self):
        """Capture screen text and verify after the countdown."""
        try:
            self.capture_label.setText("Capturing screen now...")

            false_news = []
            true_news = []

            true_news, false_news = main_process()

            self.true_news_box.setContent(true_news)
            self.fake_news_box.setContent(false_news)

            self.capture_label.setText("Capture complete!")

        except Exception as e:
            QMessageBox.warning(self, "Error", f"An error occurred: {e}")

if __name__ == "__main__":
    app = QApplication(sys.argv)
    window = VerifyApp()
    window.show()
    sys.exit(app.exec_())