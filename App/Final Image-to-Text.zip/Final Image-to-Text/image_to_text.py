import cv2
import numpy as np
import pytesseract
from PIL import ImageGrab
import time
import os
import re
import requests
from sentence_transformers import SentenceTransformer, util

import nltk
from nltk.corpus import words

nltk.download('words')

word_list = set(words.words())

pytesseract.pytesseract.tesseract_cmd = r'C:\Users\HP\AppData\Local\Programs\Tesseract-OCR\tesseract.exe'  # Adjust this path as needed

model = SentenceTransformer('all-MiniLM-L6-v2')
cleaned_lines = []

def capturescreen():
    """Capture the screen excluding the taskbar on a 1920x1080 screen."""
    screen_width = 1920 
    screen_height = 1080  
    taskbar_height = 48  
    

    bbox = (0, 0, screen_width, screen_height - taskbar_height)


    screenshot = ImageGrab.grab(bbox)
    screenshot_np = np.array(screenshot)
    screenshot_cv = cv2.cvtColor(screenshot_np, cv2.COLOR_RGB2BGR)
    
    return screenshot_cv


def extract_text(image):
    """Extract text from the provided image using Pytesseract."""
    gray_image = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY) 
    extracted_text = pytesseract.image_to_string(gray_image) 
    return extracted_text.strip()  

def save_captured_text(text):
    """Saves the refined text to a file in the current directory."""
    current_directory = os.path.dirname(os.path.abspath(__file__)) 
    file_path = os.path.join(current_directory, "captured_text.txt")
    with open(file_path, "w", encoding='utf-8') as file:
        file.write(text + "\n")

def clean_line(line):
    line = line.strip()
    

    header_footer_patterns = [
        r'^\s*(Page|Date|Confidential|Report|Header|Footer|Untitled|Draft)\s*', 
        r'^\s*\d{1,2}\s*$',  
    ]
    
    if any(re.match(pattern, line) for pattern in header_footer_patterns):
        return ""  #


    line = re.sub(r'\d{1,2}:\d{2} (AM|PM)', '', line)  
    line = re.sub(r'\d{1,2}-\d{1,2}-\d{4}', '', line)  
    line = re.sub(r'http\S+|www\S+|instagram\S+', '', line)  
    line = re.sub(r'\b\d+\b', '', line)  

    
    line = re.sub(r'[^\w\s]', '', line)  

   
    meaningless_patterns = [
        r'\b(UF|Ln|Col|UTF|tryrtfrrf5rtrcre|Untitled|asdf|loremipsum)\b',  # Nonsensical or common gibberish patterns
        r'^\s*$' 
    ]
    
    for pattern in meaningless_patterns:
        line = re.sub(pattern, '', line)
    
    line = re.sub(r'\s+', ' ', line).strip() 
    if not line or not check_meaningfulness(line):
        return ""
    return line

def check_meaningfulness(line):
    words_in_line = line.split()
    return any(word in word_list for word in words_in_line)

def extract_lines_from_file(file_path):
    global cleaned_lines
    cleaned_lines = []

    try:
        with open(file_path, 'r', encoding='utf-8') as data:
            raw_lines = data.readlines()

            for line in raw_lines:
                cleaned_line_result = clean_line(line)
                if cleaned_line_result:
                    cleaned_lines.append(cleaned_line_result)
                    
    except FileNotFoundError:
        print(f"File not found: {file_path}")
def get_articles(query):
    url = ('https://newsapi.org/v2/everything?'
           f'q={query}&'
           'sortBy=relevancy&'
           'apiKey=a668f491a41248cfb6512cbd9b349ff3')  
    response = requests.get(url)
    return response.json()

def compute_similarity(query, text):
    query_embedding = model.encode(query, convert_to_tensor=True)
    text_embedding = model.encode(text, convert_to_tensor=True)
    similarity_score = util.pytorch_cos_sim(query_embedding, text_embedding).item()
    return similarity_score

def check_query_in_articles(query, articles):
    matches = 0
    total_articles = len(articles)

    for article in articles:
        title = article.get('title', '')
        description = article.get('description', '')
        content = article.get('content', '')
        combined_text = f"{title} {description} {content}"
        similarity_score = compute_similarity(query, combined_text)

        if similarity_score >= 0.5:
            matches += 1

    return matches, total_articles



def monitor_screen_for_text_capture():
    """Captures text from the screen and verifies it against articles."""
    print("Capturing the entire screen...")

    screenshot = capturescreen() 
    text = extract_text(screenshot)

    if text.strip():  
        print(f"Captured Text: {text}") 
        save_captured_text(text) 
        print("Captured text saved to file.")
        
        current_directory = os.path.dirname(os.path.abspath(__file__))
        file_path = os.path.join(current_directory, "captured_text.txt")
        extract_lines_from_file(file_path)

        false_news = []
        true_news = []
        
        for line in cleaned_lines:
            print(f"\nVerifying line: '{line}'")
            
            adjusted_query = f"{line} news"
            response = get_articles(adjusted_query)
            content = response.get('articles', [])

            total_articles = len(content)
            matches, _ = check_query_in_articles(line, content)

           
            if (total_articles - matches == 100) or (matches == 0):
                print(f"Skipping line: '{line}' (Matched articles: {matches}, Total articles: {total_articles})")
                continue  

            if total_articles > 0:
                match_ratio = matches / total_articles

                if match_ratio < 0.65:
                    final_verdict = "False"
                    false_news.append(line)
                    print(f"Fake news detected: {line}")
                else:
                    final_verdict = "True"
                    true_news.append(line)
                    print(f"True news detected: {line}")

                print(f"The line '{line}' was semantically similar to {matches} out of {total_articles} articles.")
                print(f"Match Ratio: {match_ratio:.2f}")
                print(f"Final Verdict: {final_verdict}")
            else:
                print(f"No articles found for the line '{line}'.")

        print(f"False news: {false_news}")
        print(f"True news: {true_news}")

        return true_news, false_news 
    else:
        print("No text detected on screen.")
        return [], [] 


def main_process():
    try:
        true_news, false_news = monitor_screen_for_text_capture() 
        return true_news, false_news 
    except Exception as e:
        print(f"An error occurred: {e}")

