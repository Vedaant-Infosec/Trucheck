import torch
import re
import requests
from sentence_transformers import SentenceTransformer, util
def refine(text):
    def split_into_sentences(text):
        # Load the model and required components
        model, example_texts, languages, punct, apply_te = torch.hub.load(repo_or_dir='snakers4/silero-models', model='silero_te')

        # Apply the text processing model
        formed_sentence = apply_te(text, lan='en')
        
        # Split the formed sentence into a list
        formed_list = formed_sentence.split('. ')
        
        # Remove [UNK] from each sentence and filter meaningful sentences
        cleaned_list = [sentence.replace('[UNK]', '').strip() for sentence in formed_list]

        # Define a function to check if a sentence is meaningful
        def is_meaningful(sentence):
            # Criteria: minimum length and contains alphanumeric characters
            return len(sentence) > 10 and bool(re.search(r'[a-zA-Z0-9]', sentence))

        # Filter the cleaned list to keep only meaningful sentences
        meaningful_sentences = [sentence for sentence in cleaned_list if is_meaningful(sentence)]

        return meaningful_sentences

    

    meaningful_sentences = split_into_sentences(text)


    #News Checker
    import nltk
    from nltk import pos_tag, ne_chunk, word_tokenize
    from nltk.sentiment import SentimentIntensityAnalyzer
    #DOWNLOAD FILES
    # nltk.download('punkt_tab')
    # nltk.download('averaged_perceptron_tagger_eng')
    # nltk.download('punkt')
    # nltk.download('averaged_perceptron_tagger')
    # nltk.download('maxent_ne_chunker')
    # nltk.download('maxent_ne_chunker_tab')
    # nltk.download('words')
    # nltk.download('vader_lexicon')

    def filter_text(sentence):
        """Determine if a sentence is potentially newsworthy."""
        words = word_tokenize(sentence)
        pos_tags = pos_tag(words)
        named_entities = ne_chunk(pos_tags)
        
        # Sentiment Analysis
        sia = SentimentIntensityAnalyzer()
        sentiment_score = sia.polarity_scores(sentence)
        
        # Calculate features
        criteria = {
            'named_entities_count': sum(1 for chunk in named_entities if hasattr(chunk, 'label')),
            'sentiment_score': sentiment_score['compound'],
            'length': len(words),
            'contains_action_verbs': any(pos in ['VB', 'VBD', 'VBG', 'VBN', 'VBP', 'VBZ'] for _, pos in pos_tags),
            'contains_significant_words': any(word.lower() in ['dead', 'announced', 'revealed', 'reported', 'significant'] for word in words),
        }
        
        # Improved criteria for newsworthiness
        if criteria['named_entities_count'] > 0:  # At least one named entity might indicate significance
            return True
        if criteria['sentiment_score'] > 0.2:  # Positive sentiment might indicate important news
            return True
        if criteria['sentiment_score'] < -0.2:  # Negative sentiment might also indicate newsworthiness
            return True
        if criteria['length'] > 15 and criteria['contains_action_verbs']:  # Longer sentences with action verbs are more likely newsworthy
            return True
        if criteria['contains_significant_words']:  # Check for words commonly associated with news
            return True

        return False

    filtered_sentences = []
    # Classify sentences
    for sentence in meaningful_sentences:
        if filter_text(sentence):
            filtered_sentences.append(sentence)
    #Now we have two main lists:
    #       1) meaningful_lists - plain sentences
    #       2) filtered_sentences - properly filtered onesr
    return filtered_sentences
def refine_and_save(text, path):
    def split_into_sentences(text):
        # Load the model and required components
        model, example_texts, languages, punct, apply_te = torch.hub.load(repo_or_dir='snakers4/silero-models', model='silero_te')

        # Apply the text processing model
        formed_sentence = apply_te(text, lan='en')
        
        # Split the formed sentence into a list
        formed_list = formed_sentence.split('. ')
        
        # Remove [UNK] from each sentence and filter meaningful sentences
        cleaned_list = [sentence.replace('[UNK]', '').strip() for sentence in formed_list]

        # Define a function to check if a sentence is meaningful
        def is_meaningful(sentence):
            # Criteria: minimum length and contains alphanumeric characters
            return len(sentence) > 10 and bool(re.search(r'[a-zA-Z0-9]', sentence))

        # Filter the cleaned list to keep only meaningful sentences
        meaningful_sentences = [sentence for sentence in cleaned_list if is_meaningful(sentence)]

        return meaningful_sentences

    

    meaningful_sentences = split_into_sentences(text)


    #News Checker
    import nltk
    from nltk import pos_tag, ne_chunk, word_tokenize
    from nltk.sentiment import SentimentIntensityAnalyzer
    #DOWNLOAD FILES
    # nltk.download('punkt_tab')
    # nltk.download('averaged_perceptron_tagger_eng')
    # nltk.download('punkt')
    # nltk.download('averaged_perceptron_tagger')
    # nltk.download('maxent_ne_chunker')
    # nltk.download('maxent_ne_chunker_tab')
    # nltk.download('words')
    # nltk.download('vader_lexicon')

    def filter_text(sentence):
        """Determine if a sentence is potentially newsworthy."""
        words = word_tokenize(sentence)
        pos_tags = pos_tag(words)
        named_entities = ne_chunk(pos_tags)
        
        # Sentiment Analysis
        sia = SentimentIntensityAnalyzer()
        sentiment_score = sia.polarity_scores(sentence)
        
        # Calculate features
        criteria = {
            'named_entities_count': sum(1 for chunk in named_entities if hasattr(chunk, 'label')),
            'sentiment_score': sentiment_score['compound'],
            'length': len(words),
            'contains_action_verbs': any(pos in ['VB', 'VBD', 'VBG', 'VBN', 'VBP', 'VBZ'] for _, pos in pos_tags),
            'contains_significant_words': any(word.lower() in ['dead', 'announced', 'revealed', 'reported', 'significant'] for word in words),
        }
        
        # Improved criteria for newsworthiness
        if criteria['named_entities_count'] > 0:  # At least one named entity might indicate significance
            return True
        if criteria['sentiment_score'] > 0.2:  # Positive sentiment might indicate important news
            return True
        if criteria['sentiment_score'] < -0.2:  # Negative sentiment might also indicate newsworthiness
            return True
        if criteria['length'] > 15 and criteria['contains_action_verbs']:  # Longer sentences with action verbs are more likely newsworthy
            return True
        if criteria['contains_significant_words']:  # Check for words commonly associated with news
            return True

        return False

    filtered_sentences = []
    # Classify sentences
    for sentence in meaningful_sentences:
        if filter_text(sentence):
            filtered_sentences.append(sentence)
    #Now we have two main lists:
    #       1) meaningful_lists - plain sentences
    #       2) filtered_sentences - properly filtered onesr

# Read the text from the file and pass it to the function
    with open(path, 'w') as data:
        data = data.write(filtered_sentences)
    print('saved')

def clean(input_list):  # Accesses the text file path and processes that truth
    cleaned_lines = []
    model = SentenceTransformer('all-MiniLM-L6-v2')
    def clean_line(line):
        line = line.strip()
        line = re.sub(r'\d{1,2}:\d{2} (AM|PM)', '', line)
        line = re.sub(r'\d{1,2}-\d{1,2}-\d{4}', '', line)
        line = re.sub(r'http\S+|www\S+|instagram\S+', '', line)
        line = re.sub(r'\b\w{1,2}\b', '', line)
        print(f"Completed clean_line(): '{line}'")  # Ensure no leading/trailing spaces
        return line.strip()  # Trim any excess spaces
    
    def utilise_input(file_path):
        global cleaned_lines
        cleaned_lines = []
        for line in input_list:
            cleaned_line_result = clean_line(line)
            if cleaned_line_result:
                cleaned_lines.append(cleaned_line_result)
        print(f"Completed utilise_input: {cleaned_lines}")
        return cleaned_lines
