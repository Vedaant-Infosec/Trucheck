import sys
from PyQt5 import QtWidgets, QtCore
from PyQt5.QtWidgets import QMessageBox, QApplication, QWidget, QPushButton, QVBoxLayout, QLabel, QListWidget, QHBoxLayout
from PyQt5.QtCore import Qt, QTimer

# Assuming the following functions are already defined in your image-to-text file:
# monitor_screen_for_text_capture() to capture the text from the screen
# main_process() which populates the true_news and fake_news lists
from image_to_text import *  # Adjust this import based on your actual file name

class CollapsibleBox(QtWidgets.QWidget):
    def __init__(self, title="", parent=None):
        super(CollapsibleBox, self).__init__(parent)

        light_sky_blue = "#a3d8f4"  # Lighter version of sky blue for the titles

        self.toggle_button = QtWidgets.QToolButton(
            text=title, checkable=True, checked=False
        )
        self.toggle_button.setStyleSheet(f"QToolButton {{ border: none; background-color: {light_sky_blue}; font-size: 22px; color: white; text-align: center; font-family: 'Lucida Sans'; padding: 8px}}")
        self.toggle_button.setToolButtonStyle(QtCore.Qt.ToolButtonTextBesideIcon)
        self.toggle_button.setArrowType(QtCore.Qt.RightArrow)
        self.toggle_button.pressed.connect(self.on_pressed)

        button_layout = QtWidgets.QHBoxLayout()
        button_layout.addStretch()  # Stretchable space on the left
        button_layout.addWidget(self.toggle_button)
        button_layout.addStretch()  # Stretchable space on the right

        self.content_area = QtWidgets.QScrollArea(maximumHeight=0, minimumHeight=0)
        self.content_area.setSizePolicy(QtWidgets.QSizePolicy.Expanding, QtWidgets.QSizePolicy.Fixed)
        self.content_area.setFrameShape(QtWidgets.QFrame.NoFrame)

        lay = QtWidgets.QVBoxLayout(self)
        lay.setSpacing(0)
        lay.setContentsMargins(0, 0, 0, 0)
        lay.addLayout(button_layout)
        lay.addWidget(self.content_area)

        self.list_widget = QListWidget()
        self.content_area.setWidget(self.list_widget)
        self.list_widget.setStyleSheet("background-color: white; font-size: 18px; color: black; font-family: 'Lucida Sans'")

    @QtCore.pyqtSlot()
    def on_pressed(self):
        checked = self.toggle_button.isChecked()
        self.toggle_button.setArrowType(QtCore.Qt.DownArrow if not checked else QtCore.Qt.RightArrow)
        self.content_area.setMaximumHeight(self.list_widget.sizeHint().height() if not checked else 0)
        self.toggle_button.setChecked(not checked)

    def setContent(self, items):
        self.list_widget.clear()
        if items:
            self.list_widget.addItems(items)
        else:
            self.list_widget.addItem("Nothing yet, go on, verify something!")
        # Update size to ensure collapsible works as expected
        self.content_area.setMaximumHeight(self.list_widget.sizeHint().height())
        self.adjustSize()

class VerifyApp(QWidget):
    def __init__(self):
        super().__init__()

        # Set up the window
        self.setWindowTitle("TruCheck Text Verifier")
        self.setFixedSize(600, 600)
        self.setStyleSheet("background-color: #f0f8ff;")  # Apple blue background

        # Create a heading label for the application
        self.heading_label = QLabel("TruCheck", self)
        self.heading_label.setAlignment(Qt.AlignCenter)
        self.heading_label.setStyleSheet("font-size: 29px; font-weight: bold; color: #d14c4a; font-family: 'Lucida Sans';")

        # Set up the layout
        layout = QVBoxLayout()
        layout.addWidget(self.heading_label)

        # Create buttons
        self.verify_button = QPushButton("Verify", self)
        self.verify_button.setStyleSheet("background-color: #d14c4a; color: white; font-size: 20px; padding: 10px; border: none; border-radius: 5px; font-family: 'Lucida Sans';")

        # Connect the button click to verification process
        self.verify_button.clicked.connect(self.run_verification)

        # Add button to layout
        layout.addWidget(self.verify_button)

        # Create a label to display the capture countdown
        self.capture_label = QLabel(self)
        self.capture_label.setAlignment(Qt.AlignCenter)
        self.capture_label.setStyleSheet("font-size: 20px; color: #d14c4a; font-family: 'Lucida Sans';")
        layout.addWidget(self.capture_label)

        # Create a horizontal layout for the collapsible boxes
        h_layout = QHBoxLayout()

        # Create collapsible boxes for True News and Fake News
        self.true_news_box = CollapsibleBox("True News")
        self.fake_news_box = CollapsibleBox("Fake News")

        # Initialize the content of the collapsible boxes
        self.true_news_box.setContent([])
        self.fake_news_box.setContent([])

        # Add the collapsible boxes to the horizontal layout
        h_layout.addWidget(self.true_news_box)
        h_layout.addWidget(self.fake_news_box)

        # Add the horizontal layout to the main layout
        layout.addLayout(h_layout)

        # Set the layout for the window
        self.setLayout(layout)

    def run_verification(self):
        """Runs the main process to capture screen text and verify."""
        try:
            # Show the message and start a timer to capture the screen after 3 seconds
            self.capture_label.setText("Capturing screen in 3 seconds...")
            QTimer.singleShot(3000, self.capture_screen)  # 3000 ms = 3 seconds

        except Exception as e:
            QMessageBox.warning(self, "Error", f"An error occurred: {e}")

    def capture_screen(self):
        """Capture screen text and verify after 3 seconds."""
        try:
            self.capture_label.setText("Capturing screen now...")

            false_news = []
            true_news = []

            # Run the main process from your image-to-text module
            main_process()

            # Assuming the true and false news lists are populated within main_process
            # true_news and false_news lists need to be passed into collapsibles
            self.true_news_box.setContent(true_news)
            self.fake_news_box.setContent(false_news)

            # Reset the label after capturing
            self.capture_label.setText("Capture complete!")

        except Exception as e:
            QMessageBox.warning(self, "Error", f"An error occurred: {e}")

# Main loop
if __name__ == "__main__":
    app = QApplication(sys.argv)
    window = VerifyApp()
    window.show()
    sys.exit(app.exec_())
