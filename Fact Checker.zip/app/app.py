import sys
from PyQt5 import QtWidgets, QtCore
from PyQt5.QtWidgets import QApplication, QWidget, QPushButton, QVBoxLayout, QTextEdit, QLabel, QListWidget, QHBoxLayout, QMessageBox
from PyQt5.QtCore import Qt
from refiner import *
from returner import*
#from fact_check import *

class CollapsibleBox(QtWidgets.QWidget):
    def __init__(self, title="", parent=None):
        super(CollapsibleBox, self).__init__(parent)

        # Define a lighter version of sky blue for the titles
        light_sky_blue = "#a3d8f4"

        self.toggle_button = QtWidgets.QToolButton(
            text=title, checkable=True, checked=False
        )
        self.toggle_button.setStyleSheet(f"QToolButton {{ border: none; background-color: {light_sky_blue}; font-size: 22px; color: white; text-align: center; font-family: 'Lucida Sans'; padding: 8px}}")

        self.toggle_button.setToolButtonStyle(QtCore.Qt.ToolButtonTextBesideIcon)
        self.toggle_button.setArrowType(QtCore.Qt.RightArrow)
        self.toggle_button.pressed.connect(self.on_pressed)

        # Center the button in the layout
        button_layout = QtWidgets.QHBoxLayout()
        button_layout.addStretch()  # Add stretchable space on the left
        button_layout.addWidget(self.toggle_button)
        button_layout.addStretch()  # Add stretchable space on the right

        self.content_area = QtWidgets.QScrollArea(maximumHeight=0, minimumHeight=0)
        self.content_area.setSizePolicy(QtWidgets.QSizePolicy.Expanding, QtWidgets.QSizePolicy.Fixed)
        self.content_area.setFrameShape(QtWidgets.QFrame.NoFrame)

        lay = QtWidgets.QVBoxLayout(self)
        lay.setSpacing(0)
        lay.setContentsMargins(0, 0, 0, 0)
        lay.addLayout(button_layout)  # Use the button layout
        lay.addWidget(self.content_area)

        self.list_widget = QListWidget()
        self.content_area.setWidget(self.list_widget)
        self.list_widget.setStyleSheet("background-color: white; font-size: 18px; color: black; font-family: 'Lucida Sans'")


    @QtCore.pyqtSlot()
    def on_pressed(self):
        checked = self.toggle_button.isChecked()
        self.toggle_button.setArrowType(QtCore.Qt.DownArrow if not checked else QtCore.Qt.RightArrow)
        self.content_area.setMaximumHeight(self.list_widget.sizeHint().height() if not checked else 0)
        self.toggle_button.setChecked(not checked)

    def setContent(self, items):
        self.list_widget.clear()
        if items:
            self.list_widget.addItems(items)
        else:
            self.list_widget.addItem("Nothing yet, go on, verify something!")

class VerifyApp(QWidget):
    def __init__(self):
        super().__init__()

        # Set up the window
        self.setWindowTitle("TruCheck Text Verifier")
        self.setFixedSize(600, 600)
        self.setStyleSheet("background-color: #f0f8ff;")  # Apple blue background

        # Create a heading label for the application
        self.heading_label = QLabel("TruCheck", self)
        self.heading_label.setAlignment(Qt.AlignCenter)
        self.heading_label.setStyleSheet("font-size: 29px; font-weight: bold; color: #007aff; font-family: 'Lucida Sans';")  # Apple Blue color

        # Create a text box (QTextEdit)
        self.text_box = QTextEdit(self)
        self.text_box.setStyleSheet("background-color: white; border: 1px solid #007aff; padding: 10px; font-size: 20px; color: black; font-family: 'Lucida Sans';")
        self.text_box.setPlaceholderText("Enter a News Article")

        # Create a button labeled "Verify"
        self.verify_button = QPushButton("Verify", self)
        self.verify_button.clicked.connect(self.verify_text)
        self.verify_button.setStyleSheet("background-color: #007aff; color: white; font-size: 20px; padding: 10px; border: none; border-radius: 5px; font-family: 'Lucida Sans';")

        # Create a label for the verifying message
        self.verifying_label = QLabel("Verifying...", self)
        self.verifying_label.setAlignment(Qt.AlignCenter)
        self.verifying_label.setStyleSheet("font-size: 20px; color: #007aff; font-family: 'Lucida Sans';")
        self.verifying_label.hide()  # Initially hide the label

        # Create a label for the results message
        self.results_label = QLabel("", self)
        self.results_label.setAlignment(Qt.AlignCenter)
        self.results_label.setStyleSheet("font-size: 20px; color: #007aff; font-family: 'Lucida Sans';")
        self.results_label.hide()  # Initially hide the label

        # Set up the layout
        layout = QVBoxLayout()
        layout.addWidget(self.heading_label)  # Add heading label at the top
        layout.addWidget(self.text_box)

        layout.addSpacing(20)  # Space between text box and button
        layout.addWidget(self.verify_button)

        layout.addSpacing(10)  # Space between button and verifying label
        layout.addWidget(self.verifying_label)  # Add verifying label

        layout.addSpacing(20)  # Space between verifying label and results label
        layout.addWidget(self.results_label)  # Add results label

        layout.addSpacing(30)  # Space between results label and collapsibles

        # Create a horizontal layout for the collapsible boxes
        h_layout = QHBoxLayout()

        # Create collapsible boxes for True News and Fake News
        self.true_news_box = CollapsibleBox("True News")
        self.fake_news_box = CollapsibleBox("Fake News")

        # Initialize the content of the collapsible boxes
        self.true_news_box.setContent([])
        self.fake_news_box.setContent([])

        # Add the collapsible boxes to the horizontal layout
        h_layout.addWidget(self.true_news_box)
        h_layout.addWidget(self.fake_news_box)

        # Add the horizontal layout to the main layout
        layout.addLayout(h_layout)

        # Set the layout for the window
        self.setLayout(layout)

    def verify_text(self):
        # Get the text from the text box
        text = self.text_box.toPlainText()

        # Check if the input is empty
        if not text.strip():
            QMessageBox.warning(self, 'Empty Input', 'Type a message to verify first.')
            return

        # Show the verifying label
        self.verifying_label.show()
        self.results_label.hide()  # Hide results label during verification

        # Simulate a processing delay if needed (optional)
        QtCore.QTimer.singleShot(1000, self.process_verification)  # Simulate processing for 1 second

    def process_verification(self):
        query = self.text_box.toPlainText()
        refined_text_list = refine(text=query)
        seen_sentences = set()  # Track sentences that have already been processed

        true_news, fake_news = [], []
        
        for item in refined_text_list:
            if item in seen_sentences:
                continue  # Skip if sentence has already been processed
            
            verdict = process_text(item)
            
            if verdict == 'False':
                fake_news.append(item)
            elif verdict == 'True':
                true_news.append(item)

            seen_sentences.add(item)  # Add sentence to the set to avoid duplication

        # Update the content of the collapsible boxes
        self.true_news_box.setContent(true_news)
        self.fake_news_box.setContent(fake_news)

        true_count = len(true_news)
        fake_count = len(fake_news)

        if true_count > 0 or fake_count > 0:
            self.results_label.setText(f"{true_count} true news found and {fake_count} false news found")
        else:
            self.results_label.setText("No articles found related to the query.")
        
        self.results_label.show()  # Show the results
        self.verifying_label.hide()  # Hide the verifying label


# Main loop
if __name__ == "__main__":
    app = QApplication(sys.argv)
    window = VerifyApp()
    window.show()
    sys.exit(app.exec_())
