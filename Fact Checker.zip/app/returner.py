import re
import os
import requests
from sentence_transformers import SentenceTransformer, util


def process_text(query):
    model = SentenceTransformer('all-MiniLM-L6-v2')

    def get_articles(query):
        url = ('https://newsapi.org/v2/everything?'
            f'q={query}&'
            'sortBy=relevancy&'
            'apiKey=4b664366431f424ca676a878a63f4ed4')  
        response = requests.get(url)
        print(f"get_articles completed")
        return response.json()

    def compute_similarity(query, text):
        query_embedding = model.encode(query, convert_to_tensor=True)
        text_embedding = model.encode(text, convert_to_tensor=True)
        similarity_score = util.pytorch_cos_sim(query_embedding, text_embedding).item()
        
        return similarity_score

    def check_query_in_articles(query, articles):
        matches = 0
        total_articles = len(articles)

        for article in articles:
            title = article.get('title', '')
            description = article.get('description', '')
            content = article.get('content', '')
            combined_text = f"{title} {description} {content}"
            similarity_score = compute_similarity(query, combined_text)

            if similarity_score >= 0.5:
                matches += 1
        print(f"check query in articles completed: {matches} in {total_articles}")
        return matches, total_articles

    # Remove the `if __name__ == "__main__":` block and directly execute the logic inside the function
    print(f"\nVerifying line: '{query}'")
    adjusted_query = f"{query} news"
    response = get_articles(adjusted_query)
    content = response.get('articles', [])

    if content:
        matches, total_articles = check_query_in_articles(query, content)
        match_ratio = matches / total_articles if total_articles > 0 else 0

        if match_ratio >= 0.65:
            final_verdict = "True"
        else:
            final_verdict = "False"

        print(f"The line '{query}' was semantically similar to {matches} out of {total_articles} articles.")
        print(f"Match Ratio: {match_ratio:.2f}")
        print(f"Final Verdict: {final_verdict}")
        return final_verdict

    else:
        print(f"No articles found for the line '{query}'.")
        final_verdict = 'No articles found'
        return final_verdict
